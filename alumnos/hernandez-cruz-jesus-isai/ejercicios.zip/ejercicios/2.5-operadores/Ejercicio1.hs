-- Ejercicio 1 (fácil) — Tema 2.5: Operadores
--
-- Implementa `restarDeDiez` como una sección: una función que resta
-- su argumento de 10 (equivalente a (10 -)).
-- Ejemplo: restarDeDiez 3  ==  7
module Ejercicio1 (restarDeDiez) where

restarDeDiez :: Int -> Int
restarDeDiez = (10 -)
