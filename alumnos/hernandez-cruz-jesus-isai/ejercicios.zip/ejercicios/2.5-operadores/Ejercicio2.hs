-- Ejercicio 2 (medio) — Tema 2.5: Operadores
--
-- Define tu propio operador infijo `(^^^)` que calcule potencias SIN
-- usar `^`/`^^`/`**`: multiplica `base` por sí misma `exponente` veces,
-- usando recursión.
-- Ejemplo: 2 ^^^ 10  ==  1024
module Ejercicio2 ((^^^)) where

infixr 8 ^^^

(^^^) :: Int -> Int -> Int
base ^^^ 0 = 1
base ^^^ exponente
  | exponente < 0 = error "El exponente no puede ser negativo para potencias enteras"
  | otherwise = base * (base ^^^ (exponente - 1))
