-- Ejercicio 1 (fácil) — Tema 2.8: Evaluación perezosa
--
-- Implementa `primerosNFibonacci`, que regresa los primeros `n`
-- números de Fibonacci (0, 1, 1, 2, 3, 5, ...), usando una lista
-- infinita perezosa (no una fórmula cerrada ni una lista fija).
-- Ejemplo: primerosNFibonacci 6  ==  [0,1,1,2,3,5]
module Ejercicio1 (primerosNFibonacci) where

primerosNFibonacci :: Int -> [Integer]
primerosNFibonacci n = take n fibonacci
  where
    fibonacci = 0 : 1 : zipWith (+) fibonacci (tail fibonacci)
