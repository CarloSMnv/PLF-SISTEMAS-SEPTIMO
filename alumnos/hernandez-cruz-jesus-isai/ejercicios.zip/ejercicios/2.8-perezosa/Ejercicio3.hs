-- Ejercicio 3 (más difícil) — Tema 2.8: Evaluación perezosa
--
-- Implementa `primerMayorQue`, que recibe un umbral y una lista
-- (posiblemente infinita) y regresa el primer elemento mayor al
-- umbral -- sin recorrer la lista completa (por eso funciona incluso
-- con listas infinitas como [0..]).
-- Ejemplo: primerMayorQue 100 [0..]  ==  101
module Ejercicio3 (primerMayorQue) where

primerMayorQue :: Int -> [Int] -> Int
primerMayorQue _ [] = error "No hay elementos mayores que el umbral"
primerMayorQue umbral (x:xs)
  | x > umbral = x
  | otherwise = primerMayorQue umbral xs
