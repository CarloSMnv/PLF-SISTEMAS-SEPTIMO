-- Ejercicio 2 (medio) — Tema 2.8: Evaluación perezosa
--
-- Implementa `primerosNPrimos`, que regresa los primeros `n` números
-- primos usando la criba de Eratóstenes sobre una lista infinita de
-- candidatos (empezando en 2).
-- Ejemplo: primerosNPrimos 5  ==  [2,3,5,7,11]
module Ejercicio2 (primerosNPrimos) where

primerosNPrimos :: Int -> [Int]
primerosNPrimos n = take n (criba [2..])
  where
    criba (p:xs) = p : criba (filter (\x -> x `mod` p /= 0) xs)
    criba [] = []
