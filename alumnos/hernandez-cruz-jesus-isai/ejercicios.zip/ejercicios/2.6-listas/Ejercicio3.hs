-- Ejercicio 3 (más difícil) — Tema 2.6: Aplicaciones de las listas
--
-- Implementa `sumaConFoldr`, que suma los elementos de una lista
-- usando `foldr` (NO uses la función `sum` ya hecha).
-- Ejemplo: sumaConFoldr [1,2,3,4]  ==  10
module Ejercicio3 (sumaConFoldr) where

sumaConFoldr :: [Int] -> Int
sumaConFoldr xs = foldr (+) 0 xs
