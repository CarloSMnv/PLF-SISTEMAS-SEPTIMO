-- Ejercicio 1 (fácil) — Tema 2.6: Aplicaciones de las listas
--
-- Implementa `duplicarTodos` usando `map`: regresa una lista nueva
-- con cada elemento multiplicado por 2.
-- Ejemplo: duplicarTodos [1,2,3]  ==  [2,4,6]
module Ejercicio1 (duplicarTodos) where

duplicarTodos :: [Int] -> [Int]
duplicarTodos xs = map (* 2) xs
