-- Ejercicio 3 (más difícil) — Tema 2.4: Intervalos
--
-- Implementa `primerosNPares`, que regresa los primeros `n` números
-- pares no negativos, usando un rango INFINITO ([0,2..]) y `take`.
-- Ejemplo: primerosNPares 4  ==  [0,2,4,6]
module Ejercicio3 (primerosNPares) where

primerosNPares :: Int -> [Int]
primerosNPares n = take n [0, 2..]
