-- Ejercicio 2 (medio) — Tema 2.4: Intervalos
--
-- Implementa `multiplosDe`, que regresa la lista de múltiplos de `n`
-- desde `n` hasta `limite`, usando la notación [n,2n..limite].
-- Ejemplo: multiplosDe 3 15  ==  [3,6,9,12,15]
module Ejercicio2 (multiplosDe) where

multiplosDe :: Int -> Int -> [Int]
multiplosDe 0 _ = []
multiplosDe n limite = [n, 2 * n .. limite]
